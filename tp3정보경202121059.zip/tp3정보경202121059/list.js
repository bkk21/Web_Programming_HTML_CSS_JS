window.addEventListener('load', function(){
	
	var todos = document.getElementsByClassName('todo-item');
	var removes = document.getElementsByClassName('remove');
	document.getElementById('add-item').addEventListener('click', addItem, false);
	document.querySelector('.todo-list').addEventListener('click', toggleCompleted, false);
	document.querySelector('.todo-list').addEventListener('click', removeItem, false);
	
	function toggleCompleted(e) {
		console.log('=' + e.target.className);
		if(e.target.className.indexOf('todo-item') < 0) {
			return;
		}
		console.log(e.target.className.indexOf('completed'));
		if(e.target.className.indexOf('completed') > -1) {
			console.log(' ' + e.target.className);
			e.target.className = e.target.className.replace(' completed', '');
		} else {
			console.log('-' + e.target.className);
			e.target.className += ' completed';			
		}
	}
	
	function addItem() {
		var list = document.querySelector('ul.todo-list');
		var newItem = document.getElementById('new-item-text').value;
		var newListItem = document.createElement('li');
		newListItem.className = 'todo-item';
		newListItem.innerHTML = newItem + '<span class="remove"></span>';
		list.insertBefore(newListItem, document.querySelector('.todo-new'));
		
	}
	
	function valueField(input,val){
	if(input.value == "")
			input.value=val;
		
	}
	
	function clearField(input,val){
		if(input.value == val)
			input.value="";
	}
	
	function removeItem(e) {
		if(e.target.className.indexOf('remove') < 0) {
			return;
		}
		
	function handle(e){
		var keycode 
		if(e.keyCode === ""){
			}
		return false;
	}
		var el = e.target.parentNode;
		el.parentNode.removeChild(el);
	}
	
});