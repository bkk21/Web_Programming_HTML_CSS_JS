function myFunc(name) 
        { 
     		 myWin = window.open("","popup_sample","width=200,height=100"); 
      		 myWin.document.open(); 
     		 myWin.document.write("<HTML><HEAD><TITLE>추천</TITLE></HEAD>"); 
    		 myWin.document.write("<BODY bgColor='80c0ff'>");  


            if(name == '맑음')
            {
                myWin.document.write("<P ALIGN='center'><B><br>맑은 날씨에는 가벼운<br> 맨투맨을 추천합니다.</B></P>"); 
            }

            else if(name == '흐림')
            {
                myWin.document.write("<P ALIGN='center'><B><br>흐린 날씨에는 얇은<br> 가디건을 추천합니다.</B></P>"); 
            }

            else if(name == '비')
            {
                myWin.document.write("<P ALIGN='center'><B><br>비오는 날씨에는<br> 자켓을 추천합니다.</B></P>"); 
            }

            myWin.document.write("</BODY></HTML>"); 
      		myWin.document.close();
	    }