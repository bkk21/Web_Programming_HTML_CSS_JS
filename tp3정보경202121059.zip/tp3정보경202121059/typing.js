const typeSpace = document.getElementById('typing');
const cursur = document.getElementById('blink');
const typeList = ["", "T", "TO", "TO-", "TO-D", "TO-DO", "TO-DO ", "TO-DO L", "TO-DO LI", "TO-DO LIS", "TO-DO LIST", "TO-DO LIST!"];

let i = 0;
setInterval(function() {
    typeSpace.innerText = typeList[i];
    i += 1;
    if (i == typeList.length) {
        i = 0;
    }
}, 150);

setInterval(function() {
    if (cursur.innerText == '|') {
        cursur.innerText = '';
    } 
    else {
        cursur.innerText = '|';
    }
}, 700);